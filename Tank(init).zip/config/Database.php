<?php

namespace config;

/**
 * (配置)MongoDB数据库
 */
use tank\Env\env;


class SQL
{
        /**
         * 数据库类型选择
         */
        public static $ConnectSQL =
                [
                        /* 数据库类型 */
                        "SQLType" => '',

                ];
        /**
         * MongoDB数据库配置
         */
        public static $MongoDB =
                [
                        /* 数据库地址 */
                        "SQLLocalhost" => "",
                        /* 数据库端口 */
                        "SQLPort" => 27017,
                        /* 数据库名称 */
                        "SQLDatabaseName" => '',
                ];
        /**
         * MySQL数据库配置
         */
        public static $MySQL =
                [
                        /* 数据库地址 */
                        "SQLLocalhost" => "",
                        /* 数据库端口 */
                        "SQLPort" => 3306,
                        /* 数据库名称 */
                        "SQLDatabaseName" => '',
                        /* MySQL用户 */
                        "MySQL_User" => "",
                        /* MySQL密码 */
                        "MySQL_PassWord" => "",
                ];

}

