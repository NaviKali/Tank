<?php
/**
 * APP配置文件
 */
return [
    /**
     * 是否开启App场景化
     */
    "IsStartApp"=>true,
    /**
     * 代参
     * 200->通过
     */
    "AppCode" => 200,
    /**
     * Base64解码参数 | GET or POST
     */
    "AppParamsType"=>"GET",
    /**
     * 不可调用类
     */
    "AppNotCallClass" => [],
];