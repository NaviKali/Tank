<?php

namespace config;


return [
    //*是否禁止Edge浏览器使用
    "isStopEdge" => true,
];