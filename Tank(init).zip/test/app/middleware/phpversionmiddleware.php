<?php

namespace app\middleware;

use tank\Error\httpError;


class phpversionmiddleware
{
    /**
     * PHP版本验证
     * @static
     * @throws httpError
     * @return mixed
     */
    public static function Handle()
    {
        if ((int)PHP_VERSION < 8) {
            throw new httpError("PHP版本过低![请安装>=8.0.2版本的PHP]");
        } else {
            return null;
        }
    }
}