<?php

namespace app\middleware;

use tank\Request\Request;
use tank\Web\http;

class routerunreal
{
    /**
     * 路由虚幻
     */
    public static function handle()
    {
        $params = Request::param();
        if (empty($params["isStartUnreal"])){
            header("Location:".http::RouterUnreal());
        }
    }

}