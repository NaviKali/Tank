<?php

namespace config;

use config\Base\Base as Base;

use function tank\getConStantUrl;



#       全局-常量语                   #
#       写入属于你的常量语             #
#       2024-05-13      # 

Base::AutomaticInclude(getConStantUrl());
