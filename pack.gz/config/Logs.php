<?php

namespace config;

/**
 * (配置）日志
 */
class Logs
{
        /**
         * 日志配置信息
         */
        public static $Log =
                [
                        /* 后缀名 */
                        "suffix" => "log",
                        /* 严格写入 */
                        "strict" => true,
                ];

}