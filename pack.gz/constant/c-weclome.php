<?php
const WECLOME_HELLO = "你好!";
const WECLOME_BACK = "欢迎回来!";
