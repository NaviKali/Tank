<?php
namespace app\middleware;

use function tank\BathVerParams;

/**
 * 中间件
 */
class middleware
{
        /**
         * 中间件定义
         * @static
         * @return mixed
         */
        public static function Handle()
        {
        }
}
